Lancassian Chess - deploy-ready site (one file: index.html, no build step, no server code).

Deploy (about 1 minute, free):
 1. Go to https://app.netlify.com/drop (free account)
 2. Drag this whole "site" folder onto the page.
 3. You get a link like https://something.netlify.app. Rename it under Site settings > Change site name.
 Alternatives: GitHub Pages, Cloudflare Pages, Vercel. A custom domain can be attached in any of them.

Playing a friend online: open your site, press "Play a friend", then "Host a game" and send your friend the invite link (or the 6-letter code).
They open it and join. The host's game settings are used. Moves pass through the free public ntfy.sh message relay (no account, no server of
your own), so it works across different networks and phones. Needs the site hosted online and an internet connection. Anyone who guesses a room code
could listen in, so treat it as casual play.

Spectators: when hosting, press "Copy spectator link" and send it to anyone; they watch live, read-only. Or they press "Play a friend" and enter the code under "Watch".
Install as an app: on the deployed (https) site, use your browser's "Install" / "Add to Home Screen". The game then opens full-screen and the computer opponent works offline.
Keep all files in this folder together (index.html, manifest.json, sw.js and the two icons).

New: Puzzles button (built-in set + puzzles mined from your own games + a daily puzzle), custom starting armies and sound packs (under Customize).

New: Myosia Worldbuilder (worldbuilder.html), a tabletop map and combat tool. Reach it from the menu on the chess page; it links back to the chess page. Keep worldbuilder.html in the same folder as index.html.
 Paint maps, add tokens, run initiative, roll dice, use fog of war, and host a table for players (GM + players via a room code, same free relay as chess). Maps save in the browser and export as files.
